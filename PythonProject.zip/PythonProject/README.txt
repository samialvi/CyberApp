# Smart Market Analyzer (SMA)

Smart Market Analyzer (SMA) is an open-source Python desktop application with a graphical user interface (GUI) that aggregates
financial data from multiple public APIs. It offers insights into stock prices, cryptocurrency trends, exchange rates, and market news.

## 🔧 Features

- 📈 Visualized stock data (historical prices)
- 💰 Cryptocurrency price monitoring
- 💱 Live currency exchange rate graph
- 📰 Latest market news in tabular format
- 🔄 Real-time data refresh with a single click

## 💻 Technologies Used

- Python 3
- Tkinter (GUI)
- Matplotlib (charts)
- Requests (HTTP requests)
- unittest (testing)

## 📡 APIs Integrated

1. [Alpha Vantage](https://www.alphavantage.co/)
2. [CoinGecko or Alpha Vantage for crypto]
3. [NewsAPI](https://newsapi.org/) or a mocked API
4. [ExchangeRate-API](https://www.exchangerate-api.com/)

## 📦 Installation

```bash
pip install -r requirements.txt
python main.py
